# To-do-list-app
 A Todo list application implemented with jquery

 Dependencies used include Jquery, html
